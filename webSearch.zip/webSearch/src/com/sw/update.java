package com.sw;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;

// THIS PAGE ALLOWS THE USER TO UPDATE THEIR INFO & STORES IT INTO THE VARIABLES

public class update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public update() {
        super();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		
		//if any of the fields are empty send them back to the login page
		if(username.isEmpty() || password.isEmpty() || email.isEmpty())
		{
			RequestDispatcher req = request.getRequestDispatcher("login.jsp");
			req.include(request, response);
		}
		else // send them to a confirmation page
		{
			RequestDispatcher req = request.getRequestDispatcher("newInfo.jsp");
			req.forward(request, response);
		}
	}
 
}

