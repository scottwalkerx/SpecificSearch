package service;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.sw.User;

public class UserService {	
	
	//THIS CLASS CONNECTS TO THE DB & SETS JAVA VARIABLES TO SQL VARIABLES *********************************

	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	   static final String DB_URL = "jdbc:mysql://localhost:3306/phase2"; //phase2 is DB name in SQL
	   //  Database credentials
	   static final String USER = "scott"; //SQL USERNAME
	   static final String PASS = "apple"; //SQL PW
	   
	  public static User retrieveUser(String username, String password) throws SQLException, ClassNotFoundException {
		  
		  Class.forName("com.mysql.jdbc.Driver");

	      // Open a connection
	      System.out.println("Connecting to database...");
	     Connection conn = DriverManager.getConnection(DB_URL,USER,PASS);

	     // create query
	     System.out.println("Creating statement...");
	     Statement stmt = conn.createStatement();
	     
	      String sql;
	      sql = "select * from user where name = \"" + username + "\" AND password = \"" + password + "\"";
	      ResultSet rs = stmt.executeQuery(sql);     
	      if (rs.next()) {
	    	  User user = new User();
	    	  user.setName(username);
	    	  user.setPassword(password); 
	    	  
	      } else {
	    	   System.out.println("Check creditentials!! \n Could not find user " + username);
	      }
	  
	      String updt = "update user set email=? , name=? where password=?";

	      PreparedStatement preparedStatement =
	              conn.prepareStatement(updt);
	      // set the new user info
	      preparedStatement.setString(1, "tim@gmail.com"); // I want to put user input in these parameters -----
	      preparedStatement.setString(2, "Tim");
	      preparedStatement.setString (3, "password");
	      // show the # of rows updated in sql
	      int rowsAffected = preparedStatement.executeUpdate();
	      System.out.println("rows affected: " + rowsAffected);
		return null;
           
	  };
	
}
